Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"104\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("translation.json", 
		"URL=https://savematik.com/api/translations/ext/ru/translation.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("translation.json_2", 
		"URL=https://savematik.com/api/translations/ext/en/translation.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Origin", 
		"chrome-extension://fjnhffajgcgcbjkmbgnajpaoeniopgna");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"104\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("ext-statistic", 
		"URL=https://analytics.savematik.com/ext-statistic", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"extension_id\":\"d71700ce19de4c7690c59a8f97240cfe-ch-13\",\"transaction_id\":\"m02qr6yszj61i5yzjhygkdfj\",\"extension_version\":\"10.1.1.1\",\"os\":\"Win32\",\"browser\":\"chrome\",\"language\":\"ru\"}", 
		LAST);

	web_add_cookie("remixscreen_depth=24; DOMAIN=vk.com");

	web_add_cookie("remixscreen_dpr=1; DOMAIN=vk.com");

	web_add_cookie("remixscreen_height=1080; DOMAIN=vk.com");

	web_add_cookie("remixscreen_width=1920; DOMAIN=vk.com");

	web_add_cookie("tmr_lvid=e7608eeeaee12f4ae895700d28a4bf44; DOMAIN=vk.com");

	web_add_cookie("tmr_lvidTS=1627761204386; DOMAIN=vk.com");

	web_add_cookie("remixuas=YTg2ZDhmNDgzM2YyNDg1YzQ0YjE0NWNk; DOMAIN=vk.com");

	web_add_cookie("remixscreen_winzoom=1; DOMAIN=vk.com");

	web_add_cookie("remixlgck=d6731ea32d56e00ed6; DOMAIN=vk.com");

	web_add_cookie("remixstlid=9067225034636089837_vHvkXzmvE1EmTZnouS0tc1roFM5XwpD7HYjjMxvO6TP; DOMAIN=vk.com");

	web_add_cookie("remixrefkey=64c5383ea0fa9a59ea; DOMAIN=vk.com");

	web_add_cookie("remixcolor_scheme_mode=auto; DOMAIN=vk.com");

	web_add_cookie("remixdark_color_scheme=0; DOMAIN=vk.com");

	web_add_cookie("tmr_reqNum=91; DOMAIN=vk.com");

	web_add_cookie("remixlang=0; DOMAIN=vk.com");

	web_add_cookie("remixstid=1831124934_AkFeMX0kwJZeElgeP9UCLdgWxhbwoM0rx5pOoBJtdmT; DOMAIN=vk.com");

	web_add_cookie("remixua=41%7C-1%7C194%7C1686926087; DOMAIN=vk.com");

	web_add_cookie("remixlns=44ecfb51d07692cb82; DOMAIN=vk.com");

	web_url("feed", 
		"URL=https://vk.com/feed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("lang=ru; DOMAIN=icosrate.ru");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Origin", 
		"chrome-extension://pplhhobbdamhmboandfdcjihieaakmjd");

	web_custom_request("get", 
		"URL=http://icosrate.ru/get/?r=extensions.bot.getTasks", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"Body=config[id]=840341&config[hash]=8222037a5e5df886111c5bf6c6390913&user_agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36&version=6.2&modules[ytv][version]=15.9&modules[ytv][hash]=-177622966&modules[vkv]=1&modules[vkmedia]=2.1&modules[vk][error]=NOT_LOGINED&modules[vk][user_activity][count_activity_feed]=3&modules[vk][user_activity][count_activity_wall]=0&modules[vk][user_activity][count_activity_all]=9&modules[vk][user_activity"
		"][last_href]=https://vk.com/&modules[vk][ext_id]=8a0b6c880959c1c92c0cdbcc32c0c66b", 
		LAST);

	return 0;
}